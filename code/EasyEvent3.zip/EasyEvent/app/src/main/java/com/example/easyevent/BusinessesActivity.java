package com.example.easyevent;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class BusinessesActivity extends AppCompatActivity {

    private TextView textViewBusinesses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_businesses);

        textViewBusinesses = findViewById(R.id.textView_businesses);

        String businessType = getIntent().getStringExtra("BUSINESS_TYPE");
        textViewBusinesses.setText("Displaying businesses for type: " + businessType);

        // Here you would add logic to display the businesses of the selected type.
    }
}
