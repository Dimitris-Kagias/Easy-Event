package com.example.easyevent;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.List;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText editTextUsername = findViewById(R.id.editTextUsername);
        EditText editTextPassword = findViewById(R.id.editTextPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                List<User> users = loadUsersFromJson();
                if (users == null) {
                    Toast.makeText(LoginActivity.this, "Error loading user data", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean validUser = false;

                for (User user : users) {
                    if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                        validUser = true;
                        switch (user.getRole()) {
                            case "Customer":
                                startActivity(new Intent(LoginActivity.this, CustomerHomePageActivity.class));
                                break;
                            case "Business":
                                startActivity(new Intent(LoginActivity.this, BusinessHomePageActivity.class));
                                break;
                            case "Administrator":
                                startActivity(new Intent(LoginActivity.this, AdministratorHomePageActivity.class));
                                break;
                        }
                        break;
                    }
                }

                if (!validUser) {
                    Toast.makeText(LoginActivity.this, "Invalid login credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private List<User> loadUsersFromJson() {
        String json = null;
        try {
            InputStream is = getAssets().open("user.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
            Log.d(TAG, "user.json content: " + json); // Logging the content of the JSON file
        } catch (IOException ex) {
            Log.e(TAG, "Error reading user.json", ex);
            return null;
        }

        Gson gson = new Gson();
        Type userListType = new TypeToken<List<User>>(){}.getType();
        return gson.fromJson(json, userListType);
    }
}
