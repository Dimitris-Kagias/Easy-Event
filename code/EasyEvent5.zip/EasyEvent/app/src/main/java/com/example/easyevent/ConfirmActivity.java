package com.example.easyevent;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ConfirmActivity extends AppCompatActivity {

    private CartItem cartItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm);

        cartItem = (CartItem) getIntent().getSerializableExtra("CART_ITEM");

        TextView textView = findViewById(R.id.text_view_confirm);
        textView.setText("Ολοκλήρωση συναλλαγής για " + cartItem.getBusinessName() + "?");

        Button yesButton = findViewById(R.id.button_yes);
        Button noButton = findViewById(R.id.button_no);

        yesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseYes();
            }
        });

        noButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseNo();
            }
        });
    }

    private void chooseYes() {
        Intent intent = new Intent(this, PaymentActivity.class);
        startActivity(intent);
    }

    private void chooseNo() {
        Intent intent = new Intent(this, BuyingCartActivity.class);
        startActivity(intent);
    }
}
