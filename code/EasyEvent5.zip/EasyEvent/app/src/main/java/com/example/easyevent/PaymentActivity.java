package com.example.easyevent;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class PaymentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        Button paymentButton = findViewById(R.id.button_payment);
        paymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishBuying();
            }
        });
    }

    private void finishBuying() {
        Intent intent = new Intent(this, MessageActivity.class);
        intent.putExtra("MESSAGE", "Επιτυχής ολοκλήρωση συναλλαγής");
        startActivity(intent);
    }
}
