package com.example.easyevent;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class BusinessHomePageActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_homepage);
    }
}