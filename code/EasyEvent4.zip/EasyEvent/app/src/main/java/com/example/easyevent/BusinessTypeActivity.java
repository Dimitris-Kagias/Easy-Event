package com.example.easyevent;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class BusinessTypeActivity extends AppCompatActivity {

    private GridLayout gridLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_type);

        gridLayout = findViewById(R.id.grid_layout);

        ArrayList<String> businessTypes = getIntent().getStringArrayListExtra("BUSINESS_TYPES");

        if (businessTypes != null) {
            for (String type : businessTypes) {
                Button button = new Button(this);
                button.setText(type);
                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(BusinessTypeActivity.this, BusinessesActivity.class);
                        intent.putExtra("BUSINESS_TYPE", type);
                        startActivity(intent);
                    }
                });
                gridLayout.addView(button);
            }
        }
    }
}
