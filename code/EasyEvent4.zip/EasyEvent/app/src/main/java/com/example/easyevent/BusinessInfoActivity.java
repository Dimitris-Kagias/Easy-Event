package com.example.easyevent;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class BusinessInfoActivity extends AppCompatActivity {

    private GetBusiness business;
    private String eventType, date, time, location;

    private TextView textViewName, textViewReviews, textViewServices;
    private Button buttonAddToCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_info);

        textViewName = findViewById(R.id.text_view_name);
        textViewReviews = findViewById(R.id.text_view_reviews);
        textViewServices = findViewById(R.id.text_view_services);
        buttonAddToCart = findViewById(R.id.button_add_to_cart);

        // Λήψη των δεδομένων από το intent
        business = (GetBusiness) getIntent().getSerializableExtra("BUSINESS");
        eventType = getIntent().getStringExtra("EVENT_TYPE");
        date = getIntent().getStringExtra("DATE");
        time = getIntent().getStringExtra("TIME");
        location = getIntent().getStringExtra("LOCATION");

        // Εμφάνιση των πληροφοριών της επιχείρησης
        textViewName.setText(business.getName());
        displayReviews();
        displayServices();

        buttonAddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToCart();
                navigateBackToBusinessType();
            }
        });
    }

    private void displayReviews() {
        StringBuilder reviewsBuilder = new StringBuilder();
        if (business.getReviews() != null && !business.getReviews().isEmpty()) {
            for (Review review : business.getReviews()) {
                reviewsBuilder.append(review.getUser()).append(": ").append(review.getComment())
                        .append(" (Rating: ").append(review.getRating()).append(")").append("\n");
            }
        } else {
            reviewsBuilder.append("No reviews available.");
        }
        textViewReviews.setText(reviewsBuilder.toString());
    }

    private void displayServices() {
        StringBuilder servicesBuilder = new StringBuilder();
        if (business.getServices() != null && !business.getServices().isEmpty()) {
            for (String service : business.getServices()) {
                servicesBuilder.append(service).append("\n");
            }
        } else {
            servicesBuilder.append("No services available.");
        }
        textViewServices.setText(servicesBuilder.toString());
    }

    private void addToCart() {
        EasyEvent easyEvent = new EasyEvent(business.getName(), eventType, date, time, location);
        Gson gson = new Gson();
        String json = gson.toJson(easyEvent);

        try {
            FileOutputStream fos = openFileOutput("easyevent.json", MODE_APPEND);
            OutputStreamWriter osw = new OutputStreamWriter(fos);
            osw.write(json);
            osw.close();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void navigateBackToBusinessType() {
        Intent intent = new Intent(this, BusinessTypeActivity.class);
        startActivity(intent);
    }
}

class EasyEvent {
    private String businessName;
    private String eventType;
    private String date;
    private String time;
    private String location;

    public EasyEvent(String businessName, String eventType, String date, String time, String location) {
        this.businessName = businessName;
        this.eventType = eventType;
        this.date = date;
        this.time = time;
        this.location = location;
    }

    // Getters και setters για όλα τα πεδία
    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
