package com.example.easyevent;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BusinessesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private BusinessAdapter businessAdapter;
    private List<GetBusiness> allBusinesses;

    private String eventType;
    private String date;
    private String time;
    private String location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_businesses);

        recyclerView = findViewById(R.id.recycler_view_businesses);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Λήψη των δεδομένων από το intent
        Intent intent = getIntent();
        eventType = intent.getStringExtra("EVENT_TYPE");
        date = intent.getStringExtra("DATE");
        time = intent.getStringExtra("TIME");
        location = intent.getStringExtra("LOCATION");

        // Φόρτωση των δεδομένων των επιχειρήσεων από το αρχείο JSON
        loadBusinessesFromJson();

        // Φιλτράρισμα των επιχειρήσεων βάσει του επιλεγμένου τύπου εκδήλωσης
        List<GetBusiness> filteredBusinesses = allBusinesses.stream()
                .filter(business -> business.getBusinessType().equals(eventType))
                .collect(Collectors.toList());

        // Δημιουργία και ρύθμιση του adapter για το RecyclerView
        businessAdapter = new BusinessAdapter(this, filteredBusinesses, eventType, date, time, location);
        recyclerView.setAdapter(businessAdapter);
    }

    private void loadBusinessesFromJson() {
        String json = null;
        try {
            InputStream is = getAssets().open("business.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        if (json != null) {
            Gson gson = new Gson();
            Type listType = new TypeToken<ArrayList<GetBusiness>>() {}.getType();
            allBusinesses = gson.fromJson(json, listType);
        } else {
            allBusinesses = new ArrayList<>();
        }
    }
}
