package com.example.easyevent;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class PaymentActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_MESSAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        Button paymentButton = findViewById(R.id.button_payment);
        paymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishBuying();
            }
        });
    }

    private void finishBuying() {
        Intent intent = new Intent(this, MessageActivity.class);
        intent.putExtra("MESSAGE", "Επιτυχής ολοκλήρωση συναλλαγής");
        startActivityForResult(intent, REQUEST_CODE_MESSAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_MESSAGE) {
            if (resultCode == RESULT_OK) {
                // Επιστροφή στην BuyingCartActivity
                Intent intent = new Intent(this, BuyingCartActivity.class);
                startActivity(intent);
                finish(); // Κλείσιμο της τρέχουσας δραστηριότητας
            }
        }
    }
}
