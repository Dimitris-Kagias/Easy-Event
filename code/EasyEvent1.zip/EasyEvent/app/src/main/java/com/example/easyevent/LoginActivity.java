package com.example.easyevent;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                List<User> users = JsonHelper.loadUsers(LoginActivity.this);
                User user = null;
                for (User u : users) {
                    if (u.getUsername().equals(username) && u.getPassword().equals(password)) {
                        user = u;
                        break;
                    }
                }

                if (user != null) {
                    switch (user.getRole()) {
                        case "Customer":
                            startActivity(new Intent(LoginActivity.this, CustomerHomePageActivity.class));
                            break;
                        case "Business":
                            startActivity(new Intent(LoginActivity.this, BusinessHomePageActivity.class));
                            break;
                        case "Administrator":
                            startActivity(new Intent(LoginActivity.this, AdministratorHomePageActivity.class));
                            break;
                        default:
                            Toast.makeText(LoginActivity.this, "Unknown role", Toast.LENGTH_SHORT).show();
                            break;
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
